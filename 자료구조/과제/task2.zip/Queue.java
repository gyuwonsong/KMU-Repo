package task2;

public interface Queue<E> {
	public void clear();
	public void Enqueue(E it);
	public E Dequeue();
	public E Front();
	public E Rear();
	public int length();
}
