package task2;

public class LinkedQueue<E> implements Queue<E> {
	Link<E> head, tail;
    int size;
    
    public LinkedQueue() {
    	head = tail = new Link<E>(null, null);
    	this.size = 0;
    }
	
	public void clear() {
		head.next = null;
        tail = head;
        size = 0;
	}
	
	public void Enqueue(E it) {
		Link<E> n = new Link<E>(it, null);
		
		if(size == 0) {
			head = n;
		}
		else {
			tail.next = n;
		}
		
        tail = n;

        size++;
	}
	
	public E Dequeue() {
		E ret = head.item;
		head = head.next;
		
		size--;
		
		return ret;	
	}
	
	public E Front() {
		return head.item;
	}
	
	public E Rear() {
		return tail.item;
	}
	
	public int length() {
		return size;
	}
	
	public String toString(){
        String a = "";
        Link<E> curr = head;

        for(int i=0; i<size; i++){
            a += curr.item + ", ";
            curr = curr.next;
        }

        return a;
    }
}
