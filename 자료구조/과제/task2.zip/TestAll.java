package task2;

public class TestAll {
	public static void main(String[] args) {
		//DList 
		System.out.println(">> Result Of DList\n");
		DList<Integer> test1 = new DList<>();
		
		test1.append(1);
		test1.append(2);
		test1.append(3);
        System.out.println("DList append : " + test1);

        test1.insert(1, 4);
        System.out.println("DList insert : " + test1);

        test1.update(3, 5);
        System.out.println("DList update : " + test1);

        test1.remove(3);
        System.out.println("DList remove : " + test1);

        System.out.println("DList getValue : " + test1.getValue(0));
    
        System.out.println("\nDList length : " + test1.length());

        test1.clear();
        System.out.println("\nDList data (After clear) : " + test1);
        System.out.println("DList length (After clear) : " + test1.length());
        
        //ArrayStack
        System.out.println("\n>> Result Of ArrayStack\n");
        ArrayStack<Integer> test2 = new ArrayStack<>(10);
        
        test2.push(1);
        test2.push(2);
        test2.push(3);
        test2.push(4);
        System.out.println("ArrayStack push : " + test2);
        
        test2.pop();
        System.out.println("ArrayStack pop : " + test2);
        System.out.println("ArrayStack topValue : " + test2.topValue());
        System.out.println("\nArrayStack length : " + test2.length());
        
        test2.clear();
        System.out.println("\nArrayStack data (After clear) : " + test2);
        System.out.println("ArrayStack length (After clear) : " + test2.length());
        
        //LinkedQueue
        System.out.println("\n>> Result Of LinkedQueue\n");
        LinkedQueue<Integer> test3 = new LinkedQueue<>();
        
        test3.Enqueue(1);
        test3.Enqueue(2);
        test3.Enqueue(3);
        test3.Enqueue(4);
        System.out.println("LinkedQueue Enqueue : " + test3);
        
        test3.Dequeue();
        System.out.println("LinkedQueue Dequeue : " + test3);
        
        System.out.println("LinkedQueue Front : " + test3.Front());
        
        System.out.println("LinkedQueue Rear : " + test3.Rear());
        
        System.out.println("\nLinkedQueue length : " + test3.length());
        
        test3.clear();
        System.out.println("\nLinkedQueue data (After clear) : " + test3);
        System.out.println("LinkedQueue length (After clear) : " + test3.length());
	}
}
