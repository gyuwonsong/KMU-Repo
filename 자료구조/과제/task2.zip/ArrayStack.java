package task2;

public class ArrayStack<E> implements Stack<E> {
	int Stacksize, top;
	E [] listArray;
	
	public ArrayStack(int size) {
        this.top = -1;
        this.Stacksize = size;
        this.listArray = (E []) new Object[Stacksize];
    }
	
	public void clear() {
		top = -1;
		listArray = (E []) new Object[Stacksize];
	}
	
    public void push(E it) {
    	listArray[++top] = it;
    }
    
    public E pop() {
    	E ret = listArray[top];
    	top--;
    	return ret;
    }
    
    public E topValue() {
    	return listArray[top];
    }
    
    public int length() {
    	return top+1;
    }
    
    public String toString(){
        String a = "";
        for(int i=0; i<top+1; i++){
            a += listArray[i] + ", ";
        }

        return a;
    }
}
