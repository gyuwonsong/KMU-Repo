package task1;

public class LinkedList<E> implements List<E> {
    Link<E> head, tail;
    int size;

    public LinkedList() {
        head = tail = new Link<E>(null, null);
        size = 0;
    }

    public void clear() {
        head.next = null;
        tail = head;
        size = 0;
    }

    public void insert(int pos, E item) {
        Link<E> curr = head;
        
        for(int i=0; i<pos; i++) {
            curr = curr.next;
        }

        Link<E> n = new Link<E>(item, curr.next);
        curr.next = n;

        if(curr == tail) {
            tail = curr.next;
        }

        size++;
    }

    public void append(E item) {
        Link<E> n = new Link<E>(item, null);

        tail.next = n;
        tail = n;

        size++;
    }

    public void update(int pos, E item) {
        Link<E> curr = head;
        
        for(int i=0; i<pos; i++) {
            curr = curr.next;
        }

        curr.next.item = item;    
    }

    public E getValue(int pos) {
        Link<E> curr = head;
        
        for(int i=0; i<pos; i++) {
            curr = curr.next;
        }

        return curr.next.item;
    }

    public E remove(int pos) {
        Link<E> curr = head;
        
        for(int i=0; i<pos; i++) {
            curr = curr.next;
        }

        E ret = curr.next.item;

        if(curr.next == tail) {
            tail = curr;
        }

        curr.next = curr.next.next;
        size--;

        return ret;
    }

    public int length() {
        return size;
    }

    public String toString() {
        String a = "";
        Link<E> curr = head;

        for(int i=0; i<size; i++) {
            a += curr.next.item + ", ";
            curr = curr.next;
        }

        return a;
    }

    public static void main(String[] args) {
        List<Integer> myList = new LinkedList<>();

        System.out.println("\n>> Result Of LinkedList\n");

        myList.append(2002);
        myList.append(22);
        myList.append(13);
        System.out.println("myList append : " + myList);

        myList.insert(1, 7);
        System.out.println("myList insert : " + myList);

        myList.update(3, 21);
        System.out.println("myList update : " + myList);

        myList.remove(3);
        System.out.println("myList remove : " + myList);

        System.out.println("myList getValue : " + myList.getValue(0));
    
        System.out.println("\nmyList length : " + myList.length());

        myList.clear();
        System.out.println("\nmyList data (After clear) : " + myList);
        System.out.println("myList length (After clear) : " + myList.length());      
    }
}
