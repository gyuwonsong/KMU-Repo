package btree;

public class BSTTest {
	public static void main(String[] args) {
		BST<Integer, String> bst = new BST<>();
		
		bst.insert(1, "B");
		bst.insert(2, "r");
		bst.insert(3, "e");
		bst.insert(4, "a");
		bst.insert(6, "d");
		bst.insert(7, "b");
		bst.insert(8, "a");
		bst.insert(10, "s");
		bst.insert(11, "k");
		bst.insert(13, "e");
		bst.insert(15, "t");
		
		System.out.print(">> Result of BST Inorder (After insert) : ");
		bst.inorder(bst.root);
		
		bst.remove(3);
		System.out.println("\n\n>> BST Find 3 (After remove 3) : " + bst.find(3));
		System.out.println(">> BST Size (After remove 3) : " + bst.size());
		bst.removeany();
		System.out.println("\n>> BST Find 7 (After removeany) : " + bst.find(7));
		System.out.println(">> BST Size (After removeany) : " + bst.size());
		
		System.out.println("\n>> BST Size (Before clear) : " + bst.size());
		bst.clear();
		System.out.println(">> BST Size (After clear) : " + bst.size());
	}
}
