package btree;

public class BST<K extends Comparable <K> , E> implements Dictionary<K, E>{
	
	class Entry{
		K key;
		E element;
		
		public Entry(K key, E element) {
			this.key = key;
			this.element = element;
		}
	}
	
//	private BinNode<Entry> root;
	public BinNode<Entry> root;
	private int size;
	
	public BST() {
		root = null;
		size = 0;
	}

	public void clear() {
		root = null;
		size = 0;
	}

	public void insert(K k, E e) {
		root = insertHelper(k, e, root);
		size++;
	}

	public BinNode<Entry> insertHelper(K k, E e, BinNode<Entry> rt) {
		if(rt == null) {
			return new LNode<Entry>(new Entry(k, e));
		}
		else if(rt.element().key.compareTo(k) == 0) {
			rt.element().element = e;
		}
		else if(rt.element().key.compareTo(k) < 0) {
			if(rt.isLeaf()) {
				rt = new INode<Entry>(rt.element(), null, null);
			}
			rt.setRight(insertHelper(k, e, rt.right()));
		}
		else {
			if (rt.isLeaf()) {
				rt = new INode<Entry>(rt.element(), null, null);
			}
			rt.setLeft(insertHelper(k, e, rt.left()));
		}
		return rt;
	}
	
	public E remove(K k) {
		E ret = findHelper(k, root);
		
		if(ret != null) {
			root = removeHelper(k, root);
			size--;
		}
		
		return ret;
	}
	
	private BinNode <Entry> removeHelper(K k, BinNode<Entry> rt){
		if(rt.element().key.compareTo(k) > 0) {
			rt.setLeft(removeHelper(k, rt.left()));
		}
		else if(rt.element().key.compareTo(k) < 0) {
			rt.setRight(removeHelper(k, rt.right()));
		}
		else {
			if(rt.isLeaf()) {
				rt = null;
			}
			else if(rt.left() == null) {
				return rt.right();
			}
			else if(rt.right() == null) {
				return rt.left();
			}
			else {
				Entry leftmost = getLeftMost(rt.right());
				rt.setElement(leftmost);
				rt.setRight(removeLeftMost(rt.right()));
				return rt;
			}
		}
		if(rt.left() == null && rt.right() == null) {
			rt = new LNode<Entry>(rt.element());
		}
		return rt;
	}
	
	private Entry getLeftMost(BinNode<Entry> rt) {
		BinNode<Entry> curr = rt;
		
		while(curr.left() != null) {
			curr = curr.left();
		}
		
		return curr.element();
	}
	
	private BinNode<Entry> removeLeftMost(BinNode<Entry> rt){
		if(rt.left() == null) {
			return rt.right();
		}
		else {
			rt.setLeft(removeLeftMost(rt.left()));
			return rt;
		}
	}

	public E removeany() {
		return remove(root.element().key);
	}

	public E find(K k) {
		return findHelper(k, root);
	}
	
	public E findHelper(K k, BinNode<Entry> rt) {
		//root.element().key.compareTo(k)
		//k���� ũ�� ���, ������ ����, ������ 0
		if(rt == null) {
			return null;
		}
		else if(rt.element().key.compareTo(k) == 0) {
			return rt.element().element;
		}
		else if(rt.element().key.compareTo(k) < 0) {
			return findHelper(k, rt.right());
		}
		else {
			return findHelper(k, rt.left());
		}
	}

	public int size() {
		return size;
	}
	
	public void inorder(BinNode<Entry> rt) {
        if(rt == null) return;

        inorder(rt.left());
        System.out.print(rt.element().element); //visit
        inorder(rt.right());
    }
}
