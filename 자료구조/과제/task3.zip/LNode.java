package btree;

public class LNode<E> implements BinNode<E> {
    private E data;

    public LNode(E data) {
        this.data = data;
    }

    public E element() {
        return data;
    }

    public E setElement(E item) {
        return this.data = item;
    }

    public BinNode<E> left() {
        return null;
    }

    public BinNode<E> right() {
        return null;
    }

    public boolean isLeaf() {
        return true;
    }
}
