package btree;

public class TreeTestforINode {
    public static void main(String[] args) {
    	BinNode<String> b1 = new INode<>("B", null, null);
        BinNode<String> e1 = new INode<>("e", null, null);
        BinNode<String> d = new INode<>("d", null, null);
        BinNode<String> a1 = new INode<>("a", null, null);
        BinNode<String> k = new INode<>("k", null, null);
        BinNode<String> t = new INode<>("t", null, null);
        BinNode<String> a2 = new INode<>("a", e1, d);
        BinNode<String> e2 = new INode<>("e", k, t);
        BinNode<String> r = new INode<>("r", b1, a2);
        BinNode<String> s = new INode<>("s", a1, e2);
        BinNode<String> b2 = new INode<>("b", r, s);
        
        System.out.print(">> Result of INode \n\n");

        System.out.print("1. Result of INode Preorder : ");
        preorder(b2);
        System.out.print('\n');
        
        System.out.print("2. Result of INode Inorder : ");
        inorder(b2);
        System.out.print('\n');
        
        System.out.print("3. Result of INode Postorder : ");
        postorder(b2);
        System.out.print('\n');
    }

    static public <E> void preorder(BinNode<E> rt) {
        if(rt == null) return;

        System.out.print(rt. element()); //visit
        preorder(rt.left());
        preorder(rt.right());
    }

    static public <E> void inorder(BinNode<E> rt) {
        if(rt == null) return;

        inorder(rt.left());
        System.out.print(rt. element()); //visit
        inorder(rt.right());
    }

    static public <E> void postorder(BinNode<E> rt) {
        if(rt == null) return;

        postorder(rt.left());
        postorder(rt.right());
        System.out.print(rt. element()); //visit
    }
}
