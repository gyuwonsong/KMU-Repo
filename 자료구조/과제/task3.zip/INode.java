package btree;

public class INode<E> implements BinNode<E> {
    private E data;
    private BinNode<E> l, r;

    public INode(E data, BinNode<E> l, BinNode<E> r) {
        this.data = data;
        this.l = l;
        this.r = r;
    }

    public E element() {
        return data;
    }

    public E setElement(E item) {
        return this.data = item;
    }

    public BinNode<E> left() {
        return l;
    }

    public BinNode<E> right() {
        return r;
    }

    public boolean isLeaf() {
        return l == null && r == null;
    }
}
