package btree;

public class TreeTestforLNode {
    public static void main(String[] args) {
    	BinNode<String> b1 = new LNode<>("B");
        BinNode<String> e1 = new LNode<>("e");
        BinNode<String> d = new LNode<>("d");
        BinNode<String> a1 = new LNode<>("a");
        BinNode<String> k = new LNode<>("k");
        BinNode<String> t = new LNode<>("t");
        BinNode<String> a2 = new INode<>("a", e1, d);
        BinNode<String> e2 = new INode<>("e", k, t);
        BinNode<String> r = new INode<>("r", b1, a2);
        BinNode<String> s = new INode<>("s", a1, e2);
        BinNode<String> b2 = new INode<>("b", r, s);
        
        System.out.print(">> Result of LNode \n\n");

        System.out.print("1. Result of LNode Preorder : ");
        preorder(b2);
        System.out.print('\n');
        
        System.out.print("2. Result of LNode Inorder : ");
        inorder(b2);
        System.out.print('\n');
        
        System.out.print("3. Result of LNode Postorder : ");
        postorder(b2);
        System.out.print('\n');
    }

    static public <E> void preorder(BinNode<E> rt) {
        if(rt == null) return;

        System.out.print(rt. element()); //visit
        preorder(rt.left());
        preorder(rt.right());
    }

    static public <E> void inorder(BinNode<E> rt) {
        if(rt == null) return;

        inorder(rt.left());
        System.out.print(rt. element()); //visit
        inorder(rt.right());
    }

    static public <E> void postorder(BinNode<E> rt) {
        if(rt == null) return;

        postorder(rt.left());
        postorder(rt.right());
        System.out.print(rt. element()); //visit
    }
}
