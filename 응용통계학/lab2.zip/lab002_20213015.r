mydata = read.csv("st_data.csv")

m = as.integer(mean(mydata$midterm)) #mean
v = as.integer(var(mydata$midterm)) #variance
s = as.integer(sd(mydata$midterm)) #standard deviation

b = seq(0, 100, by = 10)
mc = cut(mydata$midterm, b, right=FALSE)
mid.freq = table(mc)

print(range(mydata$midterm))
print(m)
print(v)
print(s)
print(cbind(mid.freq))

bmp(file="aa.bmp")
hist(mydata$midterm, right=FALSE, main="Frequency", xlab="Midterm Exam", ylab="Count")
dev.off()

bmp(file="bb.bmp")
plot(mydata$midterm, mydata$final, xlab = "Midterm Exam", ylab = "Final Exam", main="Scatter")
dev.off()
