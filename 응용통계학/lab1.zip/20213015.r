mydata = read.csv("st_data.csv")
finaldata = mydata[mydata$final == 50,]

print(nrow(mydata))
print(ncol(mydata))
print(finaldata)
print(finaldata[c("ID", "final", "midterm")])