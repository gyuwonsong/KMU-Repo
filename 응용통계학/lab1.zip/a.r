x = 1
y = x + 1
print(y)