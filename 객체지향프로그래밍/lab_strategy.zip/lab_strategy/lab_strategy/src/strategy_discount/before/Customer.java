package strategy_discount.before;

public class Customer {
	String name;
	String id;
	String status;
	
	Customer(String name, String id, String status) {
		this.name = name;
		this.id = id;
		this.status = status; 
	}
}
