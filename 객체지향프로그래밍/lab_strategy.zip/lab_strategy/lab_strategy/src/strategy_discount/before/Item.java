package strategy_discount.before;

public class Item {
	String name;
	String kind;
	int number;
	int unitPrice;
	int total;
	
	Item(String name, String kind, int number, int unitPrice) {
		this.name = name;
		this.kind = kind;
		this.number = number;
		this.unitPrice = unitPrice;
		total = number * unitPrice;
	}
}
