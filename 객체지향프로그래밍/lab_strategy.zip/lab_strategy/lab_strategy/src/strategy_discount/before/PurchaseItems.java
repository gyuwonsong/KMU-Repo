package strategy_discount.before;

import java.util.Vector;

public class PurchaseItems {
	Vector<Item> list = new Vector<Item>();
	int total = 0;
	int extraDiscount = 0;
	
	void add(Item p) {
		list.add(p);
		total += p.total;
	}
	
	Vector<Item> getItems() {
		return list;
	}
}
