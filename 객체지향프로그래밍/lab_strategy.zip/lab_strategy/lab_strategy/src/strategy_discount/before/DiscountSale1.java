package strategy_discount.before;

import java.util.HashMap;
import java.util.Vector;

public class DiscountSale1 {

	int calculatePromotionDiscount(PurchaseItems pi) {
        int total = 0, dis = 0;
        for(Item item : pi.getItems())
      	  if(item.kind.equals("����")) total += item.number*item.unitPrice;
        if(total >= 50000) pi.extraDiscount += dis = 5000;
        return dis;
	}
	
}
