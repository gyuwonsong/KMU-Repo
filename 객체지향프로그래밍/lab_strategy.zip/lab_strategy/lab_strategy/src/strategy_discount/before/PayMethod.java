package strategy_discount.before;

public class PayMethod {
	String name;
	
	PayMethod(String name) {
		this.name = name;
	}
	
	String getName() {
		return name;
	}
}
