package strategy_discount.after;

import java.util.HashMap;
import java.util.Vector;

public class DiscountSale {
	HashMap<String, Object> objList = new HashMap<String, Object>();
	Vector<String> policyList = new Vector<String>();
	
	public void addDiscountStrategy(String key, DiscountStrategy ds) {
		objList.put(key, ds);
	}

	public void addDiscountPolicyList(String policy) {
		policyList.add(policy);
	}

	public void addObject(String key, Object obj) {
		objList.put(key, obj);
	}

	public void calculatePayment() {
		for(String policy : policyList) {
			DiscountStrategy ds = (DiscountStrategy)objList.get(policy);
			int dis = ds.discount(objList);
			System.out.println("(������å, ���αݾ�) = (" + policy + ", " + dis + ")");
		}
	}
}
