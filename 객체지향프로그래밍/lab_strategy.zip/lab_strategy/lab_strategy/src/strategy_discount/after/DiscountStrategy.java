package strategy_discount.after;

public interface DiscountStrategy {
	int discount(Object obj);
}
