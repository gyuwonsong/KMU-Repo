package DIP.kid.after;

public class Main {

	public static void main(String[] args) {
		Toy t1 = new Robot();
		Toy t2 = new Lego();
		
		Kid k = new Kid();
		
		k.setToy(t1);
		k.playWith();

		k.setToy(t2);
		k.playWith();
	}

}
