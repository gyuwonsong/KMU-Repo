package DIP.kid.after;

public class Lego extends Toy {
	public String toString() {
		return "Lego";
	}

}
