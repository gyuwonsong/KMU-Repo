package DIP.kid.after;

public class Kid {

	private Toy toy;
	public void setToy(Toy toy) {this.toy=toy;}
	public void playWith() {
		System.out.println(toy.toString());
	}

}
