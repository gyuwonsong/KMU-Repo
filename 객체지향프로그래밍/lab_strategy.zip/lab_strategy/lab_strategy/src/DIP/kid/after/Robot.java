package DIP.kid.after;

public class Robot extends Toy {
	public String toString() {
		return "Robot";
	}

}
