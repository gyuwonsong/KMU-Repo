package DIP.kid.after;

abstract public class Toy {

}
