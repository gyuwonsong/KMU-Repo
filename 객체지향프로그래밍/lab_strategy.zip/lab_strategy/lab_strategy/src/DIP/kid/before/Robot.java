package DIP.kid.before;

public class Robot {
	public String toString() {
		return "Robot";
	}
}
