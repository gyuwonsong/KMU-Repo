package DIP.kid.before;

public class Kid {
    Robot toy;
	public void setToy(Robot toy) {this.toy=toy;}
	public void playWith() {
		System.out.println(toy.toString());
	}
}
