package DIP.kid.before;

public class Lego {
	public String toString() {
		return "Lego";
	}

}
