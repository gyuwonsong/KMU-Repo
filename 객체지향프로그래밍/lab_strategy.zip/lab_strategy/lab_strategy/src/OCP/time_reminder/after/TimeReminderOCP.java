package OCP.time_reminder.after;

import java.util.Calendar;

public class TimeReminderOCP {
  TimeProvider tProv;
  MP3 m = new MP3();

  public void setTimeProvider(TimeProvider tProv) {
    this.tProv = tProv;
  }

  public void reminder() {
    int hour = tProv.getTime();

    if(hour >= 22) {
      m.playSong();
    }
  }

  public static void main(String[] args) {
	    TimeReminderOCP sut = new TimeReminderOCP();
	    FakeTimeProvider tProvStub = new FakeTimeProvider();
	    tProvStub.setHours(22);
	    sut.setTimeProvider(tProvStub);
	    sut.reminder();
	    
	    /*
	    RealTimeProvider tProvStub2 = new RealTimeProvider();
	    sut.setTimeProvider(tProvStub2);
	    sut.reminder();
	    */
	  }
}
