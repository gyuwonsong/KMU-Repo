package OCP.time_reminder.after;

import java.util.Calendar;

public class RealTimeProvider implements TimeProvider {
  private Calendar cal;

  public RealTimeProvider() {
    cal = Calendar.getInstance();
  }

  public void setHours(int hours) {
    // empty
  }

  public int getTime() {
    return cal.get(Calendar.HOUR_OF_DAY);
  }

}

