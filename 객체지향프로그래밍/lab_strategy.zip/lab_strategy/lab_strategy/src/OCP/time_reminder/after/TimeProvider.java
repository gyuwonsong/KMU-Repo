package OCP.time_reminder.after;

public interface TimeProvider {
  public void setHours(int hours);
  public int getTime();
}
