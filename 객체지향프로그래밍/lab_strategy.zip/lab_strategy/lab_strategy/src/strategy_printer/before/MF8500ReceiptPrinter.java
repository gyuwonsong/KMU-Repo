package strategy_printer.before;

public class MF8500ReceiptPrinter {
	public void print(StringBuffer buf) {
		System.out.println("(MF8500ReceiptPrinter)");	
		System.out.println(buf);	
	}

}
