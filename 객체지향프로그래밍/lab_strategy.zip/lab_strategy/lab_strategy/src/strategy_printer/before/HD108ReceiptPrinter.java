package strategy_printer.before;

public class HD108ReceiptPrinter {
	public void print(StringBuffer buf) {
		System.out.println("(HD108ReceiptPrinter)");	
		System.out.println(buf);	
	}
}
