package strategy_printer.before;

import java.util.ArrayList;
import java.util.Iterator;


public class Sale {
	private ArrayList<Item> items = new ArrayList<Item>();
	private HD108ReceiptPrinter printer = new HD108ReceiptPrinter();
	//private MF8500ReceiptPrinter printer = new MF8500ReceiptPrinter();
	
	public void printReceipt() {
		StringBuffer buf = new StringBuffer();
		for(Item item : items) {
			buf.append("  " + item.getName() + ": ");
			buf.append(item.getPrice() + "��\n");
		}
		printer.print(buf);
	}
	
	public void add(Item item) {
		items.add(item);
	}
}
