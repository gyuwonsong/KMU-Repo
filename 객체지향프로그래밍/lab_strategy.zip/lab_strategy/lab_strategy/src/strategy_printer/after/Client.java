package strategy_printer.after;

public class Client {
	public static void main(String[] args) {
		Item item1 = new Item("Shampoo", 3000);
		Item item2 = new Item("Cookie", 1000);
		Sale sale = new Sale();
		String expected = "(FakePrinter)\n" + "Shampoo3000Cookie1000";
		
		sale.add(item1);
		sale.add(item2);
		
		ReceiptPrinter printer;

		printer = new HD108ReceiptPrinter();
		sale.setReceiptPrinter(printer);
		sale.printReceipt();

		printer = new MF8500ReceiptPrinter();
		sale.setReceiptPrinter(printer);
		sale.printReceipt();
		
		printer = new FakePrinter();
		sale.setReceiptPrinter(printer);	
		sale.printReceipt();
		if (expected.equals(((FakePrinter)printer).getReceiptContents())) 
			System.out.println("pass!");
		else 
			System.out.println("fail!");
	}
}
