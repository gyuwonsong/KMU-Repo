package strategy_printer.after;

public class HD108ReceiptPrinter implements ReceiptPrinter {

	public void print(String s) {
		System.out.println("(HD108ReceiptPrinter)");	
		System.out.println(s);
	}
}
