package strategy_printer.after;

public interface ReceiptPrinter {
	public void print(String s);
}
