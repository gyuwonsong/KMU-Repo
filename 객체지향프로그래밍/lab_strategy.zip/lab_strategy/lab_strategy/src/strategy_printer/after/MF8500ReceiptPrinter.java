package strategy_printer.after;

public class MF8500ReceiptPrinter  implements ReceiptPrinter {

	public void print(String s) {
		System.out.println("(MF8500ReceiptPrinter)");	
		System.out.println(s);
	}
}
