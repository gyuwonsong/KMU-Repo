package strategy_printer.after;

public class FakePrinter implements ReceiptPrinter {
	String s;	
	public void print(String s) {
		this.s = "(FakePrinter)\n" + s;
	}
	
	public String getReceiptContents() {
		return s;
	}
}