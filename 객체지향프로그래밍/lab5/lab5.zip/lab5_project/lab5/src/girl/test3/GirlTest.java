package girl.test3;

class Girl {
	protected String name;

	Girl(String name) {

	}

	void show() {

	}
}

class GoodGirl extends Girl {

	GoodGirl(String name) {

	}

	void show() {

	}
}

class BestGirl extends GoodGirl {

	BestGirl(String name) {

	}

	void show() {

	}
}

public class GirlTest {
	public static void main(String[] args) {
		Girl[] girls = { new Girl("������"), new GoodGirl("����"), new BestGirl("Ȳ����") };

		for (Girl g : girls)
			g.show();
	}
}