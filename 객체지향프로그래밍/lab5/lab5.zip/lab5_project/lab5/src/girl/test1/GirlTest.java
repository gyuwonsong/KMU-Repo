package girl.test1;

class Girl {

}

class GoodGirl extends Girl {

	void show() {

	}
}

class BestGirl extends GoodGirl {

	void show() {

	}
}

public class GirlTest {
	public static void main(String[] args) {
		Girl g1 = new Girl();
		Girl g2 = new GoodGirl();
		GoodGirl gg = new BestGirl();

		// g2.show();
		gg.show();
	}
}