package command.omniButton.after1;

public interface Command {
	abstract public void execute() ;
}
