package command.remoteController;

public class ChannelUpCommand implements Command {
	private TV tv ;
	public ChannelUpCommand(TV tv) {
		this.tv = tv ;
	}

	public void execute() {
		tv.channelUp() ;
	}
}
