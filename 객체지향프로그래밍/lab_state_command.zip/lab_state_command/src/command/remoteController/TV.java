package command.remoteController;

public class TV {
	private boolean powerOn = false ;
	private boolean mute = false ;
	private int channel = 9 ;
	
	TV(int channel) {
		this.channel = channel;
	}
	
	public void power() {
		powerOn = ! powerOn ;
		if ( powerOn )
			System.out.println("Power On") ;
		else
			System.out.println("Power Off") ;		
	}
	
	public void mute() {
		// ���� �ʿ�
	}

	public void setChannel(int channel) {
		this.channel = channel ;
		System.out.println("Channel: " + this.channel) ;
	}

	public void channelUp() {
		// ���� �ʿ�
	}

	public void channelDown() {
		// ���� �ʿ�
	}
}
