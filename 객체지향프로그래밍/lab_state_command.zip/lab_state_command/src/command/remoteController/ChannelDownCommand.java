package command.remoteController;

public class ChannelDownCommand implements Command {
	private TV tv ;
	public ChannelDownCommand(TV tv) {
		this.tv = tv ;
	}

	public void execute() {
		tv.channelDown() ;
	}
}
