package command.remoteController;

public class Client {
	public static void main(String[] args) {
		TV tv = new TV(15) ;
		Command powerCommand = new PowerCommand(tv) ;
		Command muteCommand = new MuteCommand(tv) ;
		Command channelUpCommand = new ChannelUpCommand(tv) ;
		Command channelDownCommand = new ChannelDownCommand(tv) ;
		
		RemoteController rc = new RemoteController();
		
		rc.setPowerCommand(powerCommand);
		rc.setMuteCommand(muteCommand);
		rc.setChannelCommand(channelUpCommand, channelDownCommand) ;
		
		rc.powerOnOff() ;
		rc.powerOnOff() ;
		rc.powerOnOff() ;

		rc.muteOnOff() ;
		rc.muteOnOff() ;
		rc.muteOnOff() ;

		rc.channelUp() ;
		rc.channelUp() ;
		rc.channelDown() ;
		rc.channelDown() ;
	}
}
