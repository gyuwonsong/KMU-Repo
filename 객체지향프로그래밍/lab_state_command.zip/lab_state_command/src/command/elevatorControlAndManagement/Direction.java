package command.elevatorControlAndManagement;

public enum Direction {
	UP, DOWN
}
