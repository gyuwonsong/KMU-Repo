package command.elevatorControlAndManagement;

public class DestinationSelectionCommand implements Command {
	private ElevatorController controller ;
	private int destination ;
	public DestinationSelectionCommand(int destination, ElevatorController controller) {
		// ���� �ʿ�
	}
	public void execute() {
		// ���� �ʿ�
	}
}
