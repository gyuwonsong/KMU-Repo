package command.elevatorControlAndManagement;

public class ElevatorRequestCommand implements Command {
	private Direction direction ;
	private int destination ;
	private ElevatorManager manager ;	
	public ElevatorRequestCommand(int destination, Direction direction, ElevatorManager manager) {
		// ���� �ʿ�
	}
	public void execute() {
		// ���� �ʿ�
	}
}
