package state.state_fan;

public class Client {
	public static void main(String[] args) {
			Fan fan = new Fan();
			fan.power_off();
			fan.power_on();
			fan.power_on();
			fan.fan_on_off();
			fan.fan_on_off();
			fan.fan_on_off();
			fan.power_off();
	}
}
