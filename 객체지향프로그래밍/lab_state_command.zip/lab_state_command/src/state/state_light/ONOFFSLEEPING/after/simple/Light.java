package state.state_light.ONOFFSLEEPING.after.simple;

public class Light {
	private LightState state = new OFF();
	public void setState(LightState state) {
		this.state = state;
	}
	public void on_button_pushed() {
		state.on_button_pushed(this);
	}
	public void off_button_pushed() {
		state.off_button_pushed(this);
	}
}
