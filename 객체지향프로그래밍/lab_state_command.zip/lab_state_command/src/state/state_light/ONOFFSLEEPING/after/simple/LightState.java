package state.state_light.ONOFFSLEEPING.after.simple;

public interface LightState {
	public void on_button_pushed(Light light);
	public void off_button_pushed(Light light);
}
