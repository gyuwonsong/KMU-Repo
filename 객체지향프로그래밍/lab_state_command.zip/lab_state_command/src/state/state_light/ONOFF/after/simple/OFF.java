package state.state_light.ONOFF.after.simple;

public class OFF implements LightState {

	@Override
	public void on_button_pushed(Light light) {
		System.out.println("Light On!!");
		light.setState(new ON());
	}
	
	@Override
	public void off_button_pushed(Light light) {
		System.out.println("��������");
	}
}
