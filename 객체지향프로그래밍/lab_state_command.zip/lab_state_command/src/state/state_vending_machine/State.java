package state.state_vending_machine;

interface State {
	public void insertMoney(int money);
	public void pushButton(int price);
	public void returnMoney();
}
