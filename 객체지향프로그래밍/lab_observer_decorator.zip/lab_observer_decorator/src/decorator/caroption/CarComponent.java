package decorator.caroption;

public abstract class CarComponent {	
	public abstract int getPrice() ;
	public abstract String getCarInfo() ;
}
