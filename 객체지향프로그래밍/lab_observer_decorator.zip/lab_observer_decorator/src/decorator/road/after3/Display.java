package decorator.road.after3;

public abstract class Display {
	 public abstract void draw() ;
}
