package decorator.road.after3;

public class RoadDisplay extends Display {
	
	public void draw() {
		System.out.println("�⺻ ���� ǥ��") ;
	}

}
