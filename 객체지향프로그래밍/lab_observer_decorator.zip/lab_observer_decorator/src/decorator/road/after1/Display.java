package decorator.road.after1;

public abstract class Display {
	 public abstract void draw() ;
}
