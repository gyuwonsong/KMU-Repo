package decorator.road.after2;

public class RoadDisplay extends Display {
	
	public void draw() {
		System.out.println("�⺻ ���� ǥ��") ;
	}

}
