package decorator.road.after2;

public abstract class Display {
	 public abstract void draw() ;
}
