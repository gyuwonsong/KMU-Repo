package decorator.road.before2;

public class RoadDisplayWithLane extends RoadDisplay {
	public void draw() {
		super.draw();
		System.out.println("���� ǥ��") ;
	}


}
