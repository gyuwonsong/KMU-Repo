package decorator.pizza;

public interface Pizza {
    public String bakePizza();
    public float getCost();
}