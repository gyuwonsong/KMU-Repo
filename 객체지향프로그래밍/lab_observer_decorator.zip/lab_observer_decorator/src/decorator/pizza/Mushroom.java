package decorator.pizza;

public class Mushroom extends PizzaDecorator {
	 
    public Mushroom(Pizza newPizza) {
        super(newPizza);
    }
 
    @Override
    public String bakePizza() {
        return super.bakePizza() + " + Mashroom Topings";
    }
 
    @Override
    public float getCost() {
        return super.getCost()+3500;
    }
}
