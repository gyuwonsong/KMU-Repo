package decorator.pizza;

public class Client {

	public static void main(String[] args) {
        Pizza pizza = new Bulgogi(new Mushroom(new Potato(new Pepperoni(new BasePizza()))));
        System.out.println("(name) " + pizza.bakePizza() + "\n (price) " + pizza.getCost());
	}

}
