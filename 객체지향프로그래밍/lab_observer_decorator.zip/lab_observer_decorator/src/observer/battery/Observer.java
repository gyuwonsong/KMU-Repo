package observer.battery;

public interface Observer {
	abstract public void update() ;
}
