package observer.score.after2;

public interface Observer {
	abstract public void update() ;
}
