package observer.score.after1;

public interface Observer {
	abstract public void update() ;
}
