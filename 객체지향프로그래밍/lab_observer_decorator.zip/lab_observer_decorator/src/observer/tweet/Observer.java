package observer.tweet;

public interface Observer {
	public void notification(String handle, String tweet);
}
