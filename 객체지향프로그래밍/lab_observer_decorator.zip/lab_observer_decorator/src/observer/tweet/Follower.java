package observer.tweet;

public class Follower implements Observer {

	protected String name;

	public Follower(String name) {
		super();
		this.name = name;
	}

	@Override
	public void notification(String handle, String tweet) {
		System.out.println("'" +name+ "'" + "received notification from Handle:" + "'" + handle + "'," + " Tweet: " + "'"+ tweet + "'");
		// �޼ҵ� ���� �ʿ�
	}

}
