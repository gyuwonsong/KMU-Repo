package observer.tweet;

import java.util.ArrayList;
import java.util.List;

public class PublicFigure implements Subject {

	protected List<Observer> observers = new ArrayList<Observer>();
	protected String name;
	protected String handle;

	public PublicFigure(String name, String handle) {
		super();
		this.name = name;
		this.handle = "#" + handle;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHandle() {
		return handle;
	}

	public void tweet(String tweet) {
		System.out.println("Name: "+name+ "," +" Tweet: " + tweet);
		notifySubscribers(tweet);
		System.out.println();
		// �޼ҵ� ���� �ʿ�
	}

	@Override
	public synchronized void addSubscriber(Observer observer) {
		observers.add(observer);
		// �޼ҵ� ���� �ʿ�
	}

	@Override
	public synchronized void removeSubscriber(Observer observer) {
		observers.remove(observer);
		// �޼ҵ� ���� �ʿ�
	}

	@Override
	public void notifySubscribers(String tweet) {
		for (Observer o : observers)
			o.notification(handle, tweet);
		// �޼ҵ� ���� �ʿ�
	}

}
