package abstract_factory.door_motor.after1;

public class LGMotor extends Motor {	
	protected void moveMotor(Direction direction) {
		System.out.println("move LG Motor") ;
	}
}
