package abstract_factory.door_motor.after1;

public enum MotorStatus { MOVING, STOPPED}
