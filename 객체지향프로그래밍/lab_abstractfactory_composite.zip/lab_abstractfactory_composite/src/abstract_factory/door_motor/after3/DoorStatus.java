package abstract_factory.door_motor.after3;

public enum DoorStatus { CLOSED, OPENED }
