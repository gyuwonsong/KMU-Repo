package abstract_factory.door_motor.after3;

public class HyundaiMotor extends Motor {	
	protected void moveMotor(Direction direction) {
		System.out.println("move Hyundai Motor") ;
	}
}
