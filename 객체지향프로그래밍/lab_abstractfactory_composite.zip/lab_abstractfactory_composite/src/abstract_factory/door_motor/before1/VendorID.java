package abstract_factory.door_motor.before1;

public enum VendorID { LG, HYUNDAI }
