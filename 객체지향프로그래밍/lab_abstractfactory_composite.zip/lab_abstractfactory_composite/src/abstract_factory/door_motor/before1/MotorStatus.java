package abstract_factory.door_motor.before1;

public enum MotorStatus { MOVING, STOPPED}
