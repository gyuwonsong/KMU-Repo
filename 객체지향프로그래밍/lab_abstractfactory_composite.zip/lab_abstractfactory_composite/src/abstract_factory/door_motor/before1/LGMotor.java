package abstract_factory.door_motor.before1;

public class LGMotor extends Motor {	
	protected void moveMotor(Direction direction) {
		System.out.println("move LG Motor") ;
	}
}
