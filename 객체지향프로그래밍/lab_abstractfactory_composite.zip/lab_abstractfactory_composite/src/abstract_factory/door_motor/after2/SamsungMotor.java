package abstract_factory.door_motor.after2;

public class SamsungMotor extends Motor {	
	protected void moveMotor(Direction direction) {
		System.out.println("move Samsung Motor") ;
	}
}
