package abstract_factory.door_motor.after2;

public enum MotorStatus { MOVING, STOPPED}
