package abstract_factory.utensil;

public class Client {
	public static void main(String[] args) {
		AbstractUtensilFactory utensilFactory = FactoryProducer.getFactory("Microwave");
		Utensil utensil = utensilFactory.getPlate();
		System.out.println(utensil.getPrice());

		AbstractUtensilFactory utensilFactory2 = FactoryProducer.getFactory("Non-Microwave");
		Utensil utensil2 = utensilFactory2.getBowl();
		System.out.println(utensil2.getPrice());
	}
}
