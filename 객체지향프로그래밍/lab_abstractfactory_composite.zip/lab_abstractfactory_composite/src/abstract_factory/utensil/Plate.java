package abstract_factory.utensil;

public class Plate implements Utensil {
	String type;
	Double price;
	Double size;
	
	public Plate() {
		this.type = "PLATE";
		this.price = 15000.0;
		this.size = 20.0;
	}
	
	public String getType() { return type; }
	public Double getPrice() { return price; }
	public Double getSize() { return size; }
}
