package abstract_factory.utensil;

public class Bowl implements Utensil {
	String type;
	Double price;
	Double size;
	
	public Bowl() {
		this.type = "BOWL";
		this.price = 8000.0;
		this.size = 10.0;
	}
	
	public String getType() { return type; }
	public Double getPrice() { return price; }
	public Double getSize() { return size; }
}
