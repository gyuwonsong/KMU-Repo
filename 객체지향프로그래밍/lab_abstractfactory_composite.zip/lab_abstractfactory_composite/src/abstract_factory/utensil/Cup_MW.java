package abstract_factory.utensil;

public class Cup_MW implements Utensil {
	String type;
	Double price;
	Double size;
	
	public Cup_MW() {
		this.type = "Cup_MW";
		this.price = 6000.0;
		this.size = 7.0;
	}
	
	public String getType() { return type; }
	public Double getPrice() { return price; }
	public Double getSize() { return size; }
}
