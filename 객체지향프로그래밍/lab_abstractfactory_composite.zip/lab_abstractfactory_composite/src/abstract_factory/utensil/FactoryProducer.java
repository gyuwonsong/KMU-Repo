package abstract_factory.utensil;

public class FactoryProducer {
	public static AbstractUtensilFactory getFactory(String choice){
        
        if("Microwave".equalsIgnoreCase(choice)){
    		// ���� �ʿ���
        	return new MicrowaveSafeFactory();
        }
        else if("Non-Microwave".equalsIgnoreCase(choice)){
            return new NonMicrowaveSafeFactory();
        }    
        return null;
    }
}