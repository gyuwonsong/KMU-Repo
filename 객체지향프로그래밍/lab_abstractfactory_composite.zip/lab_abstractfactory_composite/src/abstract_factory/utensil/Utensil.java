package abstract_factory.utensil;

public interface Utensil{
    public String getType();
    public Double getPrice();
    public Double getSize(); 
}