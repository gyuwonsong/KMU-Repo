package abstract_factory.utensil;

public class Plate_MW implements Utensil {
	String type;
	Double price;
	Double size;
	
	public Plate_MW() {
		this.type = "PLATE_MW";
		this.price = 18000.0;
		this.size = 22.0;
	}
	
	public String getType() { return type; }
	public Double getPrice() { return price; }
	public Double getSize() { return size; }
}
