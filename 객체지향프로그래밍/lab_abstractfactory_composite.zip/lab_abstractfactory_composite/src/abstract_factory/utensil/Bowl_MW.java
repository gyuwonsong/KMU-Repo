package abstract_factory.utensil;

public class Bowl_MW implements Utensil {
	String type;
	Double price;
	Double size;
	
	public Bowl_MW() {
		this.type = "Bowl_MW";
		this.price = 12000.0;
		this.size = 14.0;
	}
	
	public String getType() { return type; }
	public Double getPrice() { return price; }
	public Double getSize() { return size; }
}
