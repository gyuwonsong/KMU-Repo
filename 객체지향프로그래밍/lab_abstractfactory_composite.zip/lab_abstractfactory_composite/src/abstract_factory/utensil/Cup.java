package abstract_factory.utensil;

public class Cup implements Utensil {
	String type;
	Double price;
	Double size;
	
	public Cup() {
		this.type = "Cup";
		this.price = 5000.0;
		this.size = 6.0;
	}
	
	public String getType() { return type; }
	public Double getPrice() { return price; }
	public Double getSize() { return size; }
}
