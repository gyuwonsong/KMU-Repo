package composite.employee_list;

public interface StatisticalStrategy2 {
	StatisticData process(Employee e);
}
