package composite.employee_list;

public class StatisticData {
	int number;
	int sum;
	
	StatisticData(int number, int sum) {
		this.number = number;
		this.sum = sum;
	}
}
