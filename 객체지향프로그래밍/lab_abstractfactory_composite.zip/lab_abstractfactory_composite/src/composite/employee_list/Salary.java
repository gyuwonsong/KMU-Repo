package composite.employee_list;

public class Salary {
	int number_employees;
	int sum_salary;
	
	Salary(int number_employees, int sum_salary) {
		this.number_employees = number_employees;
		this.sum_salary = sum_salary;
	}
}
