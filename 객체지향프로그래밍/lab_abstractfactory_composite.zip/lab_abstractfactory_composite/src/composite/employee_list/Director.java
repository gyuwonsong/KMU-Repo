package composite.employee_list;

import java.util.ArrayList; 
import java.util.List; 

public class Director extends Employee { 
	private List<Employee> directs = new ArrayList<>(); 
	
	public Director(int id, String name, String position, int age, int career, int annual_salary) { 
		super(id, name, position, age, career, annual_salary); 
	} 
	
	@Override 
	public void add(Employee e) { 
		directs.add(e); 
	} 
	
	@Override public void remove(Employee e) { 
		directs.add(e); 
	} 
	
	@Override 
	public Employee getChild(int i) { 
		return directs.get(i); 
	} 
	
	@Override 
	public List<Employee> directs() { 
		return directs; 
	} 
	
}


