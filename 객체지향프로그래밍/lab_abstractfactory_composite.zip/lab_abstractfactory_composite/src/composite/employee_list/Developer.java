package composite.employee_list;

import java.util.Collections; 
import java.util.List; 

public class Developer extends Employee { 
	public Developer(int id, String name, String position, int age, int career, int annual_salary) { 
		super(id, name, position, age, career, annual_salary); 
	} 
	
	@Override 
	public List<Employee> directs() { 
		return Collections.EMPTY_LIST; 
	} 
	
/*	public Salary average_annual_salary() { 
		Salary s = new Salary(1, annual_salary);
		return s;
	}*/
	
	public Salary average_annual_salary_manager() { 
		Salary s = new Salary(0, 0);
		return s;
	}
}

