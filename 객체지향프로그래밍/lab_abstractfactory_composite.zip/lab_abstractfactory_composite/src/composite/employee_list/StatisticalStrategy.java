package composite.employee_list;

public interface StatisticalStrategy {
	StatisticData process(Employee e);
}
