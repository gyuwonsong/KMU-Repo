package composite.employee_list;

import java.util.Collections; 
import java.util.List; 

public class Staff extends Employee { 
	public Staff(int id, String name, String position, int age, int career, int annual_salary) { 
		super(id, name, position, age, career, annual_salary); 
	} 
	
	@Override 
	public List<Employee> directs() { 
		return Collections.EMPTY_LIST; 
	} 
	
}

