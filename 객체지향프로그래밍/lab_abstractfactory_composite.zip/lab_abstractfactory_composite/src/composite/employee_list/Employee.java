package composite.employee_list;

import java.util.List; 

public abstract class Employee { 
	protected int id; 
	protected String name; 
	protected String position; 
	protected int age; 
	protected int career; 
	protected int annual_salary; 
	static StatisticalStrategy strategy;
	
	public Employee(int id, String name, String position, int age, int career, int annual_salary) { 
		this.id = id; 
		this.name = name; 
		this.position = position; 
		this.age = age; 
		this.career = career; 
		this.annual_salary = annual_salary;
	} 
	
	public int getId() { 
		return id; 
	} 
	
	public String getName() { 
		return name; 
	} 
	
	public void setStrategy(StatisticalStrategy strategy) { 
		this.strategy = strategy; 
	} 
	
	public void add(Employee e) { 
		throw new UnsupportedOperationException(); 
	} 
	
	public void remove(Employee e) { 
		throw new UnsupportedOperationException(); 
	} 
	
	public Employee getChild(int i) { 
		throw new UnsupportedOperationException(); 
	} 
	
	public List<Employee> directs() { 
		throw new UnsupportedOperationException(); 
	}
	
	public int number_employees() { 
		int count = 1;
		for(Employee e : directs())
			count += e.number_employees();
		return count; 
	}	
	
	public Salary average_annual_salary() { 
		Salary s = new Salary(1, annual_salary);
		for(Employee e : directs()) {
			Salary s2 = e.average_annual_salary();
			s.sum_salary += s2.sum_salary;
			s.number_employees += s2.number_employees;
		}
		return s;
	}
	
	public Salary average_annual_salary_manager() { 
		Salary s;
		if(this instanceof Manager) s = new Salary(1, annual_salary);
		else s = new Salary(0, 0);
		for(Employee e : directs()) {
			Salary s2 = e.average_annual_salary_manager();
			s.sum_salary += s2.sum_salary;
			s.number_employees += s2.number_employees;
		}
		return s;
	}
	
	public StatisticData process_employee_data(StatisticalStrategy2 ss) { 
		StatisticData sd;
		sd = ss.process(this);
		for(Employee e2 : this.directs()) {
			StatisticData sd2 = e2.process_employee_data(ss);
			sd.number += sd2.number;
			sd.sum += sd2.sum;
		}
		return sd;
	};	
	
	@Override 
	public String toString() { 
		return String.format("%s: %d", name, id); 
	} 
}
