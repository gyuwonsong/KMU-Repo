package composite.computer.before3;

public class HardDisk {

}
