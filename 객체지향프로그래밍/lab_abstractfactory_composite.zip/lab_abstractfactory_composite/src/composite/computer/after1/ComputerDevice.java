package composite.computer.after1;

public abstract class ComputerDevice {
	public abstract int getPrice() ;
	public abstract int getPower() ;

}
