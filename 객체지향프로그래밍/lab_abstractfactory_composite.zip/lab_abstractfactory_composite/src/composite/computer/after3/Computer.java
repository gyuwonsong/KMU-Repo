package composite.computer.after3;

public class Computer extends CompositeDevice {
}
