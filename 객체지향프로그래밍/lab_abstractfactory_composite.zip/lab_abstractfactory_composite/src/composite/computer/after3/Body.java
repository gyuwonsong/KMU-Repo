package composite.computer.after3;

public class Body extends CompositeDevice {
}
