package factory_method.elevator_scheduler.before1;

public enum Direction {
	UP, DOWN
}
