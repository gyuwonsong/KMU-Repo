package factory_method.elevator_scheduler.before1;

public class ThroughputScheduler {
	public int selectElevator(ElevatorManager manager, int destination, Direction direction) {
		return 0 ;
	}
}
