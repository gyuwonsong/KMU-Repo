package factory_method.elevator_scheduler.after1;

public enum SchedulingStrategyID { RESPONSE_TIME, THROUGHPUT, DYNAMIC }
