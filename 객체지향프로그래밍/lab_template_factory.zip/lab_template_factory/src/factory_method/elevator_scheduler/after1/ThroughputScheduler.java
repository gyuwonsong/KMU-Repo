package factory_method.elevator_scheduler.after1;

public class ThroughputScheduler implements ElevatorScheduler {

	public int selectElevator(ElevatorManager manager, int destination, Direction direction) {
		
		return 0 ;
		
	}


}
