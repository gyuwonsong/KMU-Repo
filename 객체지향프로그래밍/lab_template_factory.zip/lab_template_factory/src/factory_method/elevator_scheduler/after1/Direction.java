package factory_method.elevator_scheduler.after1;

public enum Direction {
	UP, DOWN
}
