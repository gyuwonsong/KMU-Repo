package factory_method.elevator_scheduler.after1;

public interface ElevatorScheduler {

	public int selectElevator(ElevatorManager elevatorManager, int destination, Direction direction);

}
