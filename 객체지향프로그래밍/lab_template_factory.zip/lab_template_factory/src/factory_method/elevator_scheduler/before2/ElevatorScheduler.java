package factory_method.elevator_scheduler.before2;

public interface ElevatorScheduler {
	public int selectElevator(ElevatorManager elevatorManager, int destination, Direction direction);
}
