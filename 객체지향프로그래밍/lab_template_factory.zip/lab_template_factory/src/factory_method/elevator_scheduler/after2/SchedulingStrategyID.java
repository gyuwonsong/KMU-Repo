package factory_method.elevator_scheduler.after2;

public enum SchedulingStrategyID { RESPONSE_TIME, THROUGHPUT, DYNAMIC }
