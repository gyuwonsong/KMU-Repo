package factory_method.elevator_scheduler.after2;

public enum Direction {
	UP, DOWN
}
