package factory_method.elevator_scheduler_life_cycle_scheduling;

public enum Direction {
	UP, DOWN
}
