package factory_method.elevator_scheduler_life_cycle_scheduling;

public enum SchedulingStrategyID { RESPONSE_TIME, THROUGHPUT, DYNAMIC, LIFE_CYCLE_MANAGEMENT }
