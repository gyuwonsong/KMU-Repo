package factory_method.elevator_scheduler_life_cycle_scheduling;

public class ThroughputScheduler implements ElevatorScheduler {

	private static ElevatorScheduler scheduler ;

	private ThroughputScheduler() {}

	public static ElevatorScheduler getInstance() {
		if ( scheduler == null )
			scheduler = new ThroughputScheduler() ;
		return scheduler ;
	}

	public ElevatorController selectElevator(ElevatorManager manager, int destination, Direction direction) {	
		ElevatorController cont=null;
		
 		// �޼ҵ� ���� �ʿ�
		for(ElevatorController ec : manager.controllers) {
			if(ec.curFloor == 1) {
				cont = ec;
				break;
			}
			if(ec.curFloor > destination && direction == Direction.DOWN) {
				cont = ec;
				int diff = 5000;
				int curdiff;
				curdiff = Math.abs(ec.curFloor - destination);
				if(diff > curdiff) {
					diff = curdiff;
					cont = ec;
				}
			}
			if(ec.curFloor < destination && direction == Direction.UP) {
				cont = ec;
				int diff = 5000;
				int curdiff;
				curdiff = Math.abs(ec.curFloor - destination);
				if(diff > curdiff) {
					diff = curdiff;
					cont = ec;
				}
			}
			else {
				int diff = 5000;
				int curdiff;
				curdiff = Math.abs(ec.curFloor - destination);
				if(diff > curdiff) {
					diff = curdiff;
					cont = ec;
				}
			}
		}
		
		return cont ;
	}
}