package factory_method.elevator_scheduler_life_cycle_scheduling;

public class Client {
	public static void main(String[] args) {		
		ElevatorManager emWithResponseTimerScheduler = new ElevatorManager(2, SchedulingStrategyID.RESPONSE_TIME) ;
		emWithResponseTimerScheduler.requestElevator(10, Direction.UP) ;
		emWithResponseTimerScheduler.requestElevator(7, Direction.UP) ;
		emWithResponseTimerScheduler.requestElevator(5, Direction.UP) ;
		emWithResponseTimerScheduler.requestElevator(2, Direction.DOWN) ;
		
		ElevatorManager emWithThroughputScheduler = new ElevatorManager(2, SchedulingStrategyID.THROUGHPUT) ;
		emWithThroughputScheduler.requestElevator(10, Direction.UP) ;
		emWithThroughputScheduler.requestElevator(7, Direction.UP) ;
		emWithThroughputScheduler.requestElevator(5, Direction.UP) ;
		emWithThroughputScheduler.requestElevator(2, Direction.DOWN) ;
		
		ElevatorManager emWithLifeCycleManagementScheduler = new ElevatorManager(2, SchedulingStrategyID.LIFE_CYCLE_MANAGEMENT) ;
		emWithLifeCycleManagementScheduler.controllers.get(0).life = 12;
		emWithLifeCycleManagementScheduler.controllers.get(1).life = 3;
		emWithLifeCycleManagementScheduler.requestElevator(10, Direction.UP) ;
		emWithLifeCycleManagementScheduler.requestElevator(7, Direction.UP) ;
		emWithLifeCycleManagementScheduler.requestElevator(5, Direction.UP) ;
		emWithLifeCycleManagementScheduler.requestElevator(2, Direction.DOWN) ;
		
		ElevatorManager emWithDynamicScheduler = new ElevatorManager(2, SchedulingStrategyID.DYNAMIC) ;
		emWithDynamicScheduler.requestElevator(10, Direction.UP) ;
	}
}
