package factory_method.elevator_scheduler_life_cycle_scheduling;

public interface ElevatorScheduler {
	public ElevatorController selectElevator(ElevatorManager elevatorManager, int destination, Direction direction);
}
