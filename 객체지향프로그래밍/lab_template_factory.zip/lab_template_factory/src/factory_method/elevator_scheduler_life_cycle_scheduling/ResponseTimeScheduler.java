package factory_method.elevator_scheduler_life_cycle_scheduling;

public class ResponseTimeScheduler implements ElevatorScheduler {

	private static ElevatorScheduler scheduler ;

	private ResponseTimeScheduler() {}

	public static ElevatorScheduler getInstance() {
		if ( scheduler == null )
			scheduler = new ResponseTimeScheduler() ;
		return scheduler ;
	}

	public ElevatorController selectElevator(ElevatorManager manager, int destination, Direction direction) {	
		int diff = 5000;
		int curdiff;
		ElevatorController cont=null;
		for(ElevatorController ec : manager.controllers) {
			curdiff = Math.abs(ec.curFloor-destination);
			if(curdiff == 0) { cont = ec; break; }
			if(diff > curdiff) {
				diff = curdiff;
				cont = ec;
			}
		}

		return cont ;
	}
}
