package factory_method.elevator_scheduler_life_cycle_scheduling;

import java.util.ArrayList;
import java.util.List;

public class ElevatorManager {
	List<ElevatorController> controllers ;
	private SchedulingStrategyID strategyID ;
	
	public ElevatorManager(int controllerCount, SchedulingStrategyID strategyID) {
		controllers = new ArrayList<ElevatorController>(controllerCount) ;
		for ( int i = 0 ; i < controllerCount ; i ++ ) {
			ElevatorController controller = new ElevatorController(i+1) ;
			controllers.add(controller) ;
		}
		this.strategyID = strategyID ;
	}		
	void requestElevator(int destination, Direction direction) {	
		ElevatorScheduler scheduler = SchedulerFactory.getScheduler(strategyID) ;
		System.out.println(scheduler) ; // Singleton Pattern�� �ƴ϶� Scheduler Object�� �����ϴ�
			
		ElevatorController selectedElevator = scheduler.selectElevator(this, destination, direction) ;		
		selectedElevator.gotoFloor(destination) ;
	}
}
