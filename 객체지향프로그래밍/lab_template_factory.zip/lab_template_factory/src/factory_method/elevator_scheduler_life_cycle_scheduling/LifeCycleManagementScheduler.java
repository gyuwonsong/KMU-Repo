package factory_method.elevator_scheduler_life_cycle_scheduling;

public class LifeCycleManagementScheduler implements ElevatorScheduler {

   private static ElevatorScheduler scheduler ;

   private LifeCycleManagementScheduler() {}

   public static ElevatorScheduler getInstance() {
      if ( scheduler == null )
         scheduler = new LifeCycleManagementScheduler() ;
      return scheduler ;
   }

   public ElevatorController selectElevator(ElevatorManager manager, int destination, Direction direction) {   
      ElevatorController cont=null;
      int diff = 5000;
      int upcurdiff;
      int downcurdiff;
      int life = 300;
      for(ElevatorController ec : manager.controllers) {
         if (direction.equals(Direction.UP)) {
            upcurdiff = Math.abs(ec.curFloor-destination);
            if (destination > ec.curFloor) {
               if (ec.life < life) {
                  cont = ec;
                  life = ec.life;
               }
            }
            else if (destination < ec.curFloor) {
               if(upcurdiff <diff) {
                  if (ec.life < life) {
                     cont = ec;
                     life = ec.life;
                     diff = upcurdiff;
                  }
               }else {
                  cont = ec;
                  life = ec.life;
               }
            }
         }else{
            downcurdiff = Math.abs(ec.curFloor-destination);
            if (destination < ec.curFloor) {
               if (ec.life < life) {
                  cont = ec;
                  life = ec.life;
               }
            }else if (destination > ec.curFloor) {
               if (downcurdiff < diff) {
                  if (ec.life < life) {
                     diff = downcurdiff;
                     cont = ec;
                     life = ec.life;
                  }
               }
            }else{
               if (ec.life < life) {
                  cont = ec;
                  life = ec.life;
               }
            }
         }
      }
      
      return cont ;
   }
}