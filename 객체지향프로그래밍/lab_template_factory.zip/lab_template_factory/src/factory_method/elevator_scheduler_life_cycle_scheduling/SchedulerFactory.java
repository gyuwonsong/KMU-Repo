package factory_method.elevator_scheduler_life_cycle_scheduling;

import java.util.Calendar;

// 2���� Scheduler�� Singleton���� ������ ���
public class SchedulerFactory {
	public static ElevatorScheduler getScheduler(SchedulingStrategyID strategyID) {
		ElevatorScheduler scheduler = null ;
		switch ( strategyID ) {
			case RESPONSE_TIME : scheduler = ResponseTimeScheduler.getInstance() ; break ;
			case THROUGHPUT : scheduler = ThroughputScheduler.getInstance() ; break ;
			
	 		// �޼ҵ� ���� �ʿ�
			case LIFE_CYCLE_MANAGEMENT : scheduler = LifeCycleManagementScheduler.getInstance(); break;
			
			case DYNAMIC : {
				int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY) ;
				if ( hour < 12 ) // ����
					scheduler = ResponseTimeScheduler.getInstance() ;
				else // ����
					scheduler = ThroughputScheduler.getInstance() ;
				break ;
			}
		} 
		return scheduler ;
	}
}