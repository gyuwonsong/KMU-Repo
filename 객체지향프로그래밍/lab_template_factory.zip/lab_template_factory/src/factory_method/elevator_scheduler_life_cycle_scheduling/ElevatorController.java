package factory_method.elevator_scheduler_life_cycle_scheduling;

public class ElevatorController {
	int id ;
    int curFloor ;	
    int life;
    
	public ElevatorController(int id) {
		this.id = id ;
		this.life = 0 ;
		curFloor = 1 ;
	}
	
	public void gotoFloor(int destination) {
		System.out.print("Elevator [" + id + "] Life: " + life + ", Floor: " + curFloor) ;
		life += Math.abs(destination-curFloor);
		curFloor = destination ;
		System.out.println(" ==> " + curFloor) ;
	}
}
