package factory_method.sales_plan;

class  CommercialPlan extends Plan
{
    public void setupRate()
    {
        rate=5.50;            
    }
}
