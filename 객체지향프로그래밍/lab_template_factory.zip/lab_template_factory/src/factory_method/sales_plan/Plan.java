package factory_method.sales_plan;

abstract class Plan
{
     protected double rate;
     abstract void setupRate();

     public void calculateBill(int units)
     {       
       System.out.println(rate*units);// �޼ҵ� ���� �ʿ�
       // DOMESTIC, 3
       // COMMERCIAL, 4
       // INSTITUTIONAL, 5
     }
}