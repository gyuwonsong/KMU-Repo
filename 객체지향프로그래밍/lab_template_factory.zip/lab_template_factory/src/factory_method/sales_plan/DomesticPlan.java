package factory_method.sales_plan;

class  DomesticPlan extends Plan
{
    public void setupRate()
    {
        rate=3.50;            
    }
}
