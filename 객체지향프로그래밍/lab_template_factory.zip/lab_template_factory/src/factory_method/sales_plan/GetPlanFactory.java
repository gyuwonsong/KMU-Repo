package factory_method.sales_plan;

class GetPlanFactory 
{
  
     public Plan getPlan(String planType)
    {

        if (planType.equalsIgnoreCase("DOMESTIC")){
            return new DomesticPlan();// �޼ҵ� ���� �ʿ�
         }
        if (planType.equalsIgnoreCase("COMMERCIAL")){
            return new CommercialPlan();
         }
        if (planType.equalsIgnoreCase("INSTITUTIONAL")){
            return new InstitutionalPlan();
         }
      
      return null;
   }
}