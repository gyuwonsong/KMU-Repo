package template_method.door_motor.before2;

public enum Direction { UP, DOWN }
