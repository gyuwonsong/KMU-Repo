package template_method.door_motor.before2;

public class Client {
	public static void main(String[] args) {	
		Door door = new Door() ;
		LGMotor lgMotor = new LGMotor(door) ;
		lgMotor.move(Direction.UP) ;
	}
}
