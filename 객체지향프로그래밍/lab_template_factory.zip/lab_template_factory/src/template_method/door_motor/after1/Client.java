package template_method.door_motor.after1;

public class Client {
	public static void main(String[] args) {	
		Door door = new Door() ;
		HyundaiMotor hyundaiMotor = new HyundaiMotor(door) ;
		hyundaiMotor.move(Direction.UP) ;

		Door door2 = new Door() ;
		LGMotor lgMotor = new LGMotor(door2) ;
		lgMotor.move(Direction.UP) ;
	}
}
