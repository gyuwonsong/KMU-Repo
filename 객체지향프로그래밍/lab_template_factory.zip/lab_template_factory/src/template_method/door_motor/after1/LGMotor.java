package template_method.door_motor.after1;

public class LGMotor extends Motor {
	public LGMotor(Door door) {
		super(door) ;
	}	
	protected void moveMotor(Direction direction) {
		// LG Motor�� ������Ų��.
		System.out.println("move LG Motor " + direction) ;
	}
}
