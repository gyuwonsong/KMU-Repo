package template_method.door_motor.after1;

public class HyundaiMotor extends Motor {
	public HyundaiMotor(Door door) {
		super(door) ;
	}	
	protected void moveMotor(Direction direction) {
		// Hyundai Motor�� ������Ų��.
		System.out.println("move Hyundai Motor " + direction) ;
	}
}
