package template_method.door_motor.before1;

public enum DoorStatus { CLOSED, OPENED }
