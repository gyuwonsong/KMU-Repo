package template_method.door_motor.before1;

public enum MotorStatus { MOVING, STOPPED}
