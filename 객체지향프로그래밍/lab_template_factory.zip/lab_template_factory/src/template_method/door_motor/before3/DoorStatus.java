package template_method.door_motor.before3;

public enum DoorStatus { CLOSED, OPENED }
