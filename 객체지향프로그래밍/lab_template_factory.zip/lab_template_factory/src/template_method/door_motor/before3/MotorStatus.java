package template_method.door_motor.before3;

public enum MotorStatus { MOVING, STOPPED}
