package template_method.report_generator;

import java.util.ArrayList;
import java.util.List;

public abstract class ReportGenerator {	
	public String generate(List<Customer> customers) {
		List<Customer> selectedCustomers = select(customers) ;

		String report = getReportHeader(selectedCustomers) ;

		for ( int i = 0 ; i < selectedCustomers.size() ; i ++ ) {
			Customer customer = selectedCustomers.get(i) ;
			report += getReportForCustomer(customer) ;
		}
		report += getReportFooter(selectedCustomers) ;

		return report ;
	}
	
	protected List<Customer> select(List<Customer> customers) {
		List<Customer> selected = new ArrayList<Customer>() ;
		
		// �޼ҵ� ���� �ʿ�
		for(Customer c : customers) {
			if(this.customerReportCondition(c) == true)
				selected.add(c);
		}
		return selected;
	}
	
	protected abstract boolean customerReportCondition(Customer customer) ;
	protected abstract String getReportHeader(List<Customer> customers) ;
	protected abstract String getReportForCustomer(Customer customer) ;
	protected abstract String getReportFooter(List<Customer> customers) ;
}