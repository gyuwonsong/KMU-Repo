package template_method.coffee.after;

public abstract class CoffeeTemplate
{
    // PrepareCoffee method is the template method
    public void PrepareCoffee()
    {
        BoilWater();
        AddMilk();
        AddSugar();
        AddCoffeePowder();
        System.out.println(this.getClass().getSimpleName() + " is Ready");
    }
    
    protected void BoilWater()
    {
       System.out.println("Water Boild");// �޼ҵ� ���� �ʿ�
    }
    
    protected void AddMilk()
    {
       System.out.println("Milk Added");// �޼ҵ� ���� �ʿ�
    }
    
    protected void AddSugar()
    {
       System.out.println("Sugar Added");// �޼ҵ� ���� �ʿ�
    }
    
    protected abstract void AddCoffeePowder();
}