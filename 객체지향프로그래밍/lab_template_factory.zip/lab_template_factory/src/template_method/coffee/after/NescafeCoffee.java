package template_method.coffee.after;

public class NescafeCoffee extends CoffeeTemplate
{
    protected void AddCoffeePowder()
    {      
       System.out.println("Nescafe Coffee Powder Added");// �޼ҵ� ���� �ʿ�      
    }
}