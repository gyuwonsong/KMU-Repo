package template_method.coffee.after;

public class BruCoffee extends CoffeeTemplate
{
    protected void AddCoffeePowder()
    {
    	System.out.println("Bru Coffee Powder Added");
    }
}