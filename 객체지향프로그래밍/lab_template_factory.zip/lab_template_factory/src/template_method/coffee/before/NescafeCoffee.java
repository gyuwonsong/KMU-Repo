package template_method.coffee.before;

public class NescafeCoffee extends CoffeeTemplate
{
    protected void BoilWater()
    {
    	System.out.println("Water Boild");
    }
    
    protected void AddMilk()
    {
    	System.out.println("Milk Added");
    }
    
    protected void AddSugar()
    {
    	System.out.println("Sugar Added");
    } 
    
    protected void AddCoffeePowder()
    {
    	System.out.println("Nescafe Coffee Powder Added");
    }
}