package template_method.coffee.before;

public abstract class CoffeeTemplate
{
    // PrepareCoffee method is the template method
    public void PrepareCoffee()
    {
        BoilWater();
        AddMilk();
        AddSugar();
        AddCoffeePowder();
        System.out.println(this.getClass().getSimpleName() + " is Ready");
    }
    
    protected abstract void BoilWater();
    protected abstract void AddMilk();
    protected abstract void AddSugar();
    protected abstract void AddCoffeePowder();
}