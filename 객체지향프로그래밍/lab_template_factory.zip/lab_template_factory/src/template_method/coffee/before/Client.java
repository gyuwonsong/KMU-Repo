package template_method.coffee.before;

class Client
{
	public static void main(String[] args) 
    {
    	System.out.println("Nescafe Coffee Preparation\n");
        CoffeeTemplate coffee = new NescafeCoffee();
        coffee.PrepareCoffee();
        System.out.println();
        
        System.out.println("Bru coffee preparation\n");
        coffee = new BruCoffee();
        coffee.PrepareCoffee();
    }
}