package state.state_light.ONOFFSLEEPING.before;

public class Light {
	private static int ON = 0;
	private static int OFF = 1;
	private static int SLEEPING = 1;
	private int state;
	
	public Light() {
		state = OFF;
	}
	
	public void on_button_pushed() {
		if(state == ON) {
			System.out.println("��ħ�� ����");
			state = SLEEPING;
		}
		else if(state == SLEEPING) {
			System.out.println("Light On!");
			state = ON;
		}
		else {
			System.out.println("Light On!");
			state = ON;
		}
	}
	public void off_button_pushed() {
		if(state == OFF) {
			System.out.println("���� ����");
		}
		else if(state == SLEEPING) {
			System.out.println("Light Off!");
			state = OFF;
		}
		else {
			System.out.println("Light Off!");
			state = OFF;
		}
	}
}
