package state.state_light.ONOFFSLEEPING.after.simple;

public class SLEEPING implements LightState {
	@Override
	public void on_button_pushed(Light light) {
		System.out.println("Light On Back!!");
		light.setState(new ON());
	}

	@Override
	public void off_button_pushed(Light light) {
		System.out.println("Light Off Back!!");
		light.setState(new OFF());
	}
}
