package state.state_light.ONOFF.after.singleton;

public interface LightState {
	public void on_button_pushed(Light light);
	public void off_button_pushed(Light light);
}
