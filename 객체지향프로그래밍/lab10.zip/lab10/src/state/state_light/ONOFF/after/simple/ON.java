package state.state_light.ONOFF.after.simple;

public class ON implements LightState {

	@Override
	public void on_button_pushed(Light light) {
		System.out.println("���� ����");
	}

	@Override
	public void off_button_pushed(Light light) {
		System.out.println("Light off!!");
		light.setState(new OFF());
	}

}
