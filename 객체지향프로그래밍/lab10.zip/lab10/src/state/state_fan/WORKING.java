package state.state_fan;

public class WORKING implements FanState {
	@Override
	public void power_on(Fan fan) {
		// ���� �ʿ�
		System.out.println("반응없음 ");
	}

	@Override
	public void power_off(Fan fan) {
		// ���� �ʿ�
		System.out.println("Fan Off");
		fan.setState(new OFF());
	}

	@Override
	public void fan_on_off(Fan fan) {
		// ���� �ʿ�
		System.out.println("선풍기 동작 정지 ");
		fan.setState(new ON());
	}
}
