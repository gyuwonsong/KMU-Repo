package state.state_fan;

public class OFF implements FanState {

	@Override
	public void power_on(Fan fan) {
		// ���� �ʿ�
		System.out.println("Fan On");
		fan.setState(new ON());
	}
	
	@Override
	public void power_off(Fan fan) {
		// ���� �ʿ�
		System.out.println("반응없음");
	}

	@Override
	public void fan_on_off(Fan fan) {
		// ���� �ʿ�
		System.out.println("반응없음");
	}
}
