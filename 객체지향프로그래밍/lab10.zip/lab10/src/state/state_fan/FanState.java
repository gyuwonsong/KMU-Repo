package state.state_fan;

public interface FanState {
	public void power_on(Fan fan);
	public void power_off(Fan fan);
	public void fan_on_off(Fan fan);
}
