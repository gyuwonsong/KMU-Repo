package state.state_vending_machine;

public class NoMoneyState implements State {
	VendingMachine machine;
	private int money;

	public NoMoneyState(VendingMachine machine) {
		this.machine = machine;
	}

	@Override
	public void insertMoney(int money) {
		// ���� �ʿ�
		this.money = money;
		System.out.println(money + "원을 넣었습니다.");
		System.out.println("현재 금액은 " + money + "원입니다.");
		machine.setState(machine.getEnoughMoneyState());
	}

	@Override
	public void pushButton(int price) {
		// ���� �ʿ�
		System.out.println("투입된 금액이 없습니다.");
		machine.setState(machine.getNoMoneyState());
	}

	@Override
	public void returnMoney() {
		// ���� �ʿ�
		System.out.println("반환할 금액이 없습니다.");
		machine.setState(machine.getNoMoneyState());
	}

	@Override
	public String toString() {
		// ���� �ʿ�
		return "NoMoneyState";
	}

}
