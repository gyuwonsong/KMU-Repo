package state.state_vending_machine;

public class SoldOutState implements State {
	VendingMachine machine;
	private int money;

	public SoldOutState(VendingMachine machine) {
		this.machine = machine;
	}

	@Override
	public void insertMoney(int money) {
		// ���� �ʿ�
		this.money = money;
		System.out.println("재고가 없습니다." + money + "원을 반환합니다.");
		machine.setState(machine.getSoldOutState());
	}

	@Override
	public void pushButton(int price) {
		// ���� �ʿ�
		System.out.println("... 다 팔렸네요!!!");
		machine.setState(machine.getSoldOutState());
	}

	@Override
	public void returnMoney() {
		// ���� �ʿ�
		System.out.println(machine.getMoneyBox().returnMoney() + "원이 반환되었습니다.");
		machine.setState(machine.getSoldOutState());
	}

	@Override
	public String toString() {
		// ���� �ʿ�
		return "SoldOutState";
	}
}
