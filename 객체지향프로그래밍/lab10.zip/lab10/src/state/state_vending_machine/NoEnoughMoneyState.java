package state.state_vending_machine;

public class NoEnoughMoneyState implements State {
	VendingMachine machine;
	private int money;

	public NoEnoughMoneyState(VendingMachine machine) {
		this.machine = machine;
	}

	@Override
	public void insertMoney(int money) {
		// ���� �ʿ�
		this.money = money;
		System.out.println(money + "원을 넣었습니다.");
		System.out.println("현재금액은 " + money + "원입니다.");
		machine.setState(machine.getNoEnoughMoneyState());
	}

	@Override
	public void pushButton(int price) {
		// ���� �ʿ�
		System.out.println("금액이 충분하지 않습니다.");
		machine.setState(machine.getNoEnoughMoneyState());
	}

	@Override
	public void returnMoney() {
		// ���� �ʿ�
		System.out.println(money + "원이 반환되었습니다.");
		machine.setState(machine.getNoMoneyState());
	}

	@Override
	public String toString() {
		// ���� �ʿ�
		return "NoEnoughMoneyState";
	}
}
