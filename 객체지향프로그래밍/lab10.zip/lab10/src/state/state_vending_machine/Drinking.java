package state.state_vending_machine;

public class Drinking {
	private int price;
	private int stock;

	public Drinking(int stock, int price) {
		this.stock = stock;
		this.price = price;
	}

	public void dispense() {
		this.stock--;
	}

	public int getPrice() {
		return price;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock += stock;
		System.out.println((this.stock-stock) + "에서 " + stock + "(으)로 재고가 보충되었습니다.");		
	}
}
