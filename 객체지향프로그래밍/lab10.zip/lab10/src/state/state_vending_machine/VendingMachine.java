package state.state_vending_machine;

public class VendingMachine {

	private State noMoneyState;
	private State noEnoughMoneyState;
	private State enoughMoneyState;
	private State soldOutState;
	private State state;

	private MoneyBox moneyBox;
	private Drinking drinking;

	public VendingMachine(int stock, int price) {
		noMoneyState = new NoMoneyState(this);
		noEnoughMoneyState = new NoEnoughMoneyState(this);
		enoughMoneyState = new EnoughMoneyState(this);
		soldOutState = new SoldOutState(this);

		moneyBox = new MoneyBox();
		drinking = new Drinking(stock, price);

		if (drinking.getStock() > 0) {
			state = noMoneyState;
		} else {
			state = soldOutState;
		}
	}

	public void setState(State state) {
		// ���� �ʿ�
		this.state = state;
	}

	public void insertMoney(int money) {
		// ���� �ʿ�
		state.insertMoney(money);;
	}

	public void pushButton() {
		// ���� �ʿ�
		state.pushButton(1000);
	}

	public void returnMoney() {
		// ���� �ʿ�
		state.returnMoney();
	}

	public MoneyBox getMoneyBox() {
		// ���� �ʿ�
		return moneyBox;
	}

	public Drinking getDrinking() {
		// ���� �ʿ�
		return drinking;
	}

	public State getNoMoneyState() {
		// ���� �ʿ�
		return noMoneyState;
	}

	public State getNoEnoughMoneyState() {
		// ���� �ʿ�
		return noEnoughMoneyState;
	}

	public State getEnoughMoneyState() {
		// ���� �ʿ�
		return enoughMoneyState;
	}

	public State getSoldOutState() {
		// ���� �ʿ�
		return soldOutState;
	}

	public String getState() {
		// ���� �ʿ�
		return "(현재상태) " + state;
	}

	public void setStock(int stock) {
		// ���� �ʿ�
		this.drinking.setStock(stock);
		if (drinking.getStock() > 0)
			state = noMoneyState;
		//if(state == soldOutState)
			//state = noMoneyState;
	}
	
}
