package state.state_vending_machine;

public class EnoughMoneyState implements State {
	VendingMachine machine;
	private int money;

	public EnoughMoneyState(VendingMachine machine) {
		this.machine = machine;
	}

	@Override
	public void insertMoney(int money) {
		// ���� �ʿ�
		this.money = money;
		machine.getMoneyBox().insert(money);
		System.out.println(money + "원을 넣었습니다");
		machine.getMoneyBox().insert(money);
		System.out.println("현재금액은 " + machine.getMoneyBox().getMoney() + "원입니다.");
		machine.setState(machine.getEnoughMoneyState());
	}

	@Override
	public void pushButton(int price) {
		// ���� �ʿ�
		System.out.println("음료수가 나왔습니다.");
		machine.getMoneyBox().dispense(price);
		if (machine.getMoneyBox().getMoney() > machine.getDrinking().getPrice())
			machine.setState(machine.getEnoughMoneyState());
		else if (machine.getMoneyBox().getMoney() == 0)
			machine.setState(machine.getNoMoneyState());
		else if (machine.getMoneyBox().getMoney() < machine.getDrinking().getPrice())
			machine.setState(machine.getNoEnoughMoneyState());
	}

	@Override
	public void returnMoney() {
		// ���� �ʿ�
		System.out.println(machine.getMoneyBox().returnMoney() + "원이 변환되었습니다.");
		machine.setState(machine.getNoMoneyState());
	}

	@Override
	public String toString() {
		// ���� �ʿ�
		return "EnoughMoneyState";
	}
}
