package command.elevatorControlAndManagement;

public interface Command {
	abstract public void execute() ;
}
