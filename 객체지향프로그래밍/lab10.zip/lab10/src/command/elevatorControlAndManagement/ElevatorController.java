package command.elevatorControlAndManagement;

public class ElevatorController {
	private int id ;
	private int curFloor ;	
	public ElevatorController(int id) {
		// ���� �ʿ�
	}
	public void gotoFloor(int destination) {
		// ���� �ʿ�
	}
}
