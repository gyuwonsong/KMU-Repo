package command.omniButton.after3;

public class LampOnOffCommand implements Command {
	
	enum State {ON, OFF}
	private Lamp theLamp;
	private State state = State.OFF;
	
	public LampOnOffCommand(Lamp theLamp) {
		this.theLamp = theLamp ;
	}
	
	public void execute() {
		if(state == State.OFF) 
			{ state = State.ON; theLamp.turnOn(); }
		else 
			{ state = State.OFF; theLamp.turnOff(); }
	}
}
