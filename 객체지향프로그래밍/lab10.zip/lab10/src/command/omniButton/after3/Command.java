package command.omniButton.after3;

public interface Command {
	abstract public void execute() ;
}
