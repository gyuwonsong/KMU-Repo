package command.omniButton.after2;

public interface Command {
	abstract public void execute() ;
}
