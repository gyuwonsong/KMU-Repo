package command.omniButton.before3;

public class Lamp {
	public void turnOn() {
		System.out.println("Lamp On") ;
	}
}
