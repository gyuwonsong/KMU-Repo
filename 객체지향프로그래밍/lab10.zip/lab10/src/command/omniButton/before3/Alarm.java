package command.omniButton.before3;

public class Alarm {
	public void start() {
		System.out.println("Alarming...") ;
	}
}
