package command.omniButton.after1;

public class Lamp {
	public void turnOn() {
		System.out.println("Lamp On") ;
	}
}
