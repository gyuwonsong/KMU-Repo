package command.omniButton.after1;

public class Alarm {
	public void start() {
		System.out.println("Alarming...") ;
	}
}
