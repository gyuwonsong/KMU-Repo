package command.omniButton.before1;

public class Lamp {
	public void turnOn() {
		System.out.println("Lamp On") ;
	}
}
