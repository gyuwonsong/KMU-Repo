package command.omniButton.before2;

public class Alarm {
	public void start() {
		System.out.println("Alarming...") ;
	}
}
