package command.remoteController;

public interface Command {
	abstract public void execute() ;
}
