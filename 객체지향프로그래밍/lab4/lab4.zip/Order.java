class Menu {

}

class Food {

}

class Juice {

}

class Order {

}
