package girl.base;

public class Girl {
	public String name;

	public Girl(String name) {
		this.name = name;
	}

	public void show() {
		System.out.println(name + "�� �ڹ� �ʺ����̴�.");
	}
}
